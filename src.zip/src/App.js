import React from 'react';
import './App.css';
import Chats from './pages/Chats/Chats';

function App() {
  return (
    <Chats />
  );
}

export default App;
